import logincss from "./login.css"
import help from '../common/common.js'
console.log(help.version);
// treeshaking(以lodash为例：这样会把整个lodash打进去主包里)
// import lodash from "lodash"
// const isArray = (agrs)=>{
//     console.log(lodash.isArray(args));
// }

// 要用lodash-es模块，支持分包
// import { isArray } from "lodash-es"
// const isArrayfn = (agrs)=>{
//     console.log(isArray(args));
// }

const login = ()=>{
    console.log("login加载啦。。。");
    // 请求test接口
    fetch('/api/test')
    .then(res=>res.json()) 
    .then(data=>{
        console.log("请求test接口结果：",data.message);
    })
    .catch(err=>{
        console.log("========接口报错啦=======");
        // 收集错误（可以发个短信）
        // navigator.sendBeacon("httpp://ｗｗｗ.公司cdn.com/a.gif?errinfo=" + err);
    });

    document.getElementById("app").innerHTML = `<h1 class='${logincss.login}'>login组件</h1>`
}

export {
    login
}