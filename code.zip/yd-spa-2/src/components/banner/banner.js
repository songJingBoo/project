import help from '../common/common.js'
console.log(help.version);

const asyncbanner = {
    init(){
        console.log("banner");
    }
}

export default asyncbanner;