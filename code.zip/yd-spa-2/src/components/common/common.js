function help(){};

help.version = "0.0.1";
export default help;