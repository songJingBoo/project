import Koa from "koa";
import config from "./config";
import routesInit from "./routes/routesInit";
import router from "koa-simple-router";
import errorHandler from "./middlewares/errorHandler.js";
import safeRequest from "./lib/safeRequest.js";
import log4js from "log4js";
import serve from "koa-static";
import render from "koa-swig";
import co from "co";

// 1.实例化koa
const app = new Koa();
// render配置
app.context.render = co.wrap(render({
    root: config.viewDir,
    autoescape: true,
    cache: 'memory', // disable, set to false
    ext: 'html' // 扩展名
}));

// 容错、日志处理配置
log4js.configure({
    appenders: {
        cheese: {
            type: 'file',
            filename: __dirname + '/logs/ydlogs.log'
        }
    },
    categories: {
        default: {
            appenders: ['cheese'],
            level: 'error'
        }
    }
});
const logger = log4js.getLogger('cheese');
errorHandler.error(app, logger);
// 2.初始化路由
routesInit.init(app, router);

app.use(serve(config.staticDir)); // 目的是做什么的?????????????（看koa录播）

// 3.设置监听端口
app.listen(config.port, () => {
    console.log(`yd system listening on ${config.port}`);
});