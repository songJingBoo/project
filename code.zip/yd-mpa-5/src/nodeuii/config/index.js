import { join } from "path";
import { extend } from "lodash"

let config = {
    env: process.env.NODE_ENV,
    staticDir: join(__dirname,"..","assets"), // 静态资源目录(js/css)
    viewDir: join(__dirname,"..","views"), // 页面资源目录(html)
}
// 开发环境配置
if (process.env.NODE_ENV == "development") {
    const localConfig = {
        port: 8081
    }
    config = extend(config, localConfig);
}
// 上线环境配置
if (process.env.NODE_ENV == "production") {
    const pordConfig = {
        port: 8088
    }
    config = extend(config, pordConfig);
}

export default config;