const HtmlWebpackPlugin = require('html-webpack-plugin');
const merge = require('webpack-merge');
const MiniCssExtractPlugin = require("mini-css-extract-plugin");
const ProgressBarPlugin = require('progress-bar-webpack-plugin');
const { resolve,join } = require('path');
const glob = require('glob'); // 用于遍历到所有的entry文件
const htmlAfterPlugin = require('./config/htmlAfterPlugin.js'); // webpack 基于htmlwebpackplugin的自定义插件

const argv = require('yargs-parser')(process.argv.slice(2));
const _mode = argv.mode || 'development';
const _modeflag = _mode == 'production' ? true : false;
const _mergeConfig = require(`./config/webpack.${_mode}.js`);

// 获取所有的html页面，并批量设置入口文件、插件
let _entry = {}; // 需要去处理的入口文件
let _plugins = [];
const files = glob.sync('./src/webapp/views/**/*.entry.js');
// files: './src/webapp/views/index/index-test.entry.js'
for (let item of files) {
    if (/.+\/([a-zA-Z]+-[a-zA-Z]+)(\.entry\.js$)/g.test(item) == true) { // 正则分组
        const entryKey = RegExp.$1; // 第一组为key  index-test
        _entry[entryKey] = item;
        const [dist,template] = entryKey.split("-");
        _plugins.push(
            // 用于处理模板文件，自动将css/js插入模板当中
            new HtmlWebpackPlugin({
                filename: `../views/${dist}/pages/${template}.html`,
                template: `src/webapp/views/${dist}/pages/${template}.html`, // 指到了index文件，可以用模板编程（如<%= %>）
                chunks: ['runtime','common',entryKey], // 当前模板文件用到的文件chunks集（用于给html根据打包后的name.chunk匹配引入js/css）
                minify: {// 是否压缩html（目前就没有压缩掉）
                    removeComments: _modeflag,
                    collapseWhitespace: _modeflag
                },
                inject: false // 暂不将插件转换结果插入到页面模板当中
            })
        );
    }
}

let webpackConfig = {
    entry: _entry,
    output: { // 这块的文件路径不太明白？？？？？？？？？？
        // 之所以放到assets里，以后可以将js/css一起放到CDN上
        path: join(__dirname,'./dist/assets'), // 输出文件的跟目录，所以上面的htmlwebpackplugin 里的 filename为'../views/'
        publicPath:'/',
        filename:'scripts/[name].bundle.js'
    },
    module: {
        rules: [
            // 图片、文字..的压缩
            {
                test: /\.(png|jpg|gif|ttf|otf|svg)$/i,
                use: [
                    {
                        loader: 'url-loader',
                        options: {
                            limit: 10 * 1024
                        }
                    }
                ]
            },
            {
                test: /\.css$/,
                use: [{
                    loader: MiniCssExtractPlugin.loader,
                }, {
                    loader: 'css-loader',
                    options: {
                        modules: true, // 否则login.js当中嵌入的css类不起作用
                        localIdentName: '[name]--[hash:base64:5]'
                    }
                }]
            }
        ]
    },
    // watch: !_modeflag, // 和dev:s相似，相当于热编译（一般选dev:s）
    // watchOption:{
    //     poll: 1000, // 多久检查一次文件变化（变了就编译）
    //     aggregateTimeout: 500, // 500ms内多次保存不重新编译
    // },
    optimization: {
        noEmitOnErrors: false, // 错误时是否继续编译
        // namedChunks: // 对多页很重要 
        // moduleIds: // 对多页很重要
        splitChunks: {
            cacheGroups: {
                commons: {
                    chunks: 'initial',
                    name: 'common',
                    minChunks: 2, // 一个资源被最少被引用多少次算公用包（如果小于30kb就不打出来，除非值为1强制打包）
                    maxInitialRequests: 5,
                    minSize: 0 // 多大时才会打包
                }
            }
        },
        runtimeChunk: { // webpack编译的核心代码chunk 
            name: 'runtime'
        }
    },
    profile: true, // 看每个文件的打包时间 
    plugins: [
        new MiniCssExtractPlugin({
            filename: _modeflag ? "styles/[name].[contenthash:3].css" : "styles/[name].css",
            chunkFilename: _modeflag ? "styles/[name].[contenthash:3].css" : "styles/[name].css"
        }),
        ..._plugins, // 自动将所有页面的插件配置加进来
        new htmlAfterPlugin(),
        new ProgressBarPlugin(),
    ]
}

module.exports = merge(_mergeConfig, webpackConfig);