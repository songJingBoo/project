"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _path = require("path");

var _lodash = require("lodash");

let config = {
  env: process.env.NODE_ENV,
  staticDir: (0, _path.join)(__dirname, "..", "assets"),
  viewDir: (0, _path.join)(__dirname, "..", "views")
};

if (process.env.NODE_ENV == "development") {
  const localConfig = {
    port: 8081
  };
  config = (0, _lodash.extend)(config, localConfig);
}

if (process.env.NODE_ENV == "production") {
  const pordConfig = {
    port: 8088
  };
  config = (0, _lodash.extend)(config, pordConfig);
}

exports.default = config;