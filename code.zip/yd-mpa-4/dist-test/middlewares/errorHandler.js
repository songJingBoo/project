"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
const errorHandler = {
  error(app, logger) {
    // 
    app.use(async (ctx, next) => {
      try {
        await next();
      } catch (error) {
        logger.error(error);
        ctx.status = error.status || 500;
        ctx.body = "网站挂掉了！！！";
      }
    });
    app.use(async (ctx, next) => {
      await next(); // 这块需要多了解一下

      if (404 != ctx.status) return;
      ctx.status = 404; // 打电话、发短信、发邮件、记日志。。。

      logger.error("我勒个去，出错了404!");
      ctx.body = "error啦";
    });
  }

};
exports.default = errorHandler;