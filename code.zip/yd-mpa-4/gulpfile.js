const gulp = require("gulp");
const watch = require("gulp-watch");
const babel = require("gulp-babel"); // 用于编译ES6
const rollup = require('gulp-rollup');
const replace = require('rollup-plugin-replace');
const gulpSequence = require('gulp-sequence');
const eslint = require('gulp-eslint');
// 开发环境任务
gulp.task("builddev", () => {
    return watch('src/nodeuii/**/*.js', {
        ignoreInitial: false
    }, () => {
        gulp.src('src/nodeuii/**/*.js')
            .pipe(babel({
                babelrc: false,
                plugins: ["transform-es2015-modules-commonjs"]
            }))
            .pipe(gulp.dest('dist'))
    })
});
// 上线环境任务
gulp.task("buildprod", () => {
    return gulp.src('./src/nodeuii/**/*.js')
        .pipe(babel({
            babelrc: false,
            ignore: ['./src/nodeuii/config/index.js'],
            plugins: ["transform-es2015-modules-commonjs"]
        }))
        .pipe(gulp.dest('./dist'))
});
// 上线环境rollup
gulp.task('buildconfig', () => {
    gulp.src('./src/nodeuii/**/*.js')
        .pipe(rollup({
            input: './src/nodeuii/config/index.js',
            output: {
                format: 'cjs' // 表示转为commonjs
            },
            plugins: [
                // 用于将区分dev / prod 的多余代码tree-shaking
                replace({
                    'process.env.NODE_ENV': JSON.stringify('production')
                })
            ]
        }))
        .pipe(gulp.dest('./dist'))
});
// 代码检查
gulp.task('lint',()=>{
    return gulp.src('./src/nodeuii/**/*.js')
    .pipe(eslint())
    .pipe(eslint.format())
    .pipe(eslint.failAfterError())
});

let _task = ["builddev"];
if (process.env.NODE_ENV == "production") {
    //_task = ["buildprod","buildconfig"]; // 两个都是异步，直接这样用会出问题
    _task = gulpSequence("buildprod", "buildconfig"); // 用sequence插件将两个搞成同步
}
if (process.env.NODE_ENV == "ilnt") {
    _task = ["lint"];
}

gulp.task("default", _task);