module.exports = {
    "env": {
        "node": true,
        "es6": true,
        "browser": true
    },
    "globals": {
        "$": false
    },
    "extends": "eslint:recmmended",
    "parserOptions": {
        "ecmaVersion": 6,
        "sourceType": "module"
    }
}