import('./ydfooter.css');
export default{
    init(){
        // const app = new Vue(); // 将前端框架集成进去
    }
}