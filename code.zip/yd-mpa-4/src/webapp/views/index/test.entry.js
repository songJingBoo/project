import ydfooter from "../../components/ydfooter/ydfooter.js";
ydfooter.init();