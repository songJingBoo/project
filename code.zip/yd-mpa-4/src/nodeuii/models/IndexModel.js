/**
 * @fileOverview 实现index的数据模型
 * @author songjingbo
 */

 /**
  * IndexModel类，生成一段异步的数据
  */
export default class IndexModel{
    /**
     * @constructor
     * @param {string} app koa2的上下文环境
     */
    constructor(app){
        this.app = app;
    }
    /**
     * 获取具体的API的接口数据
     * @returns {Promise}返回的异步处理结果
     * @example
     * return new Pormise
     * getData()
     */
    getData(){
        return new Promise((resolve,reject)=>{
            setTimeout(()=>{
                resolve("Hello IndexAction");
            },1000)
        })
    }
}