//import path from "path";
import { extend } from "lodash"

let config = {
    env: process.env.NODE_ENV
}

if (process.env.NODE_ENV == "development") {
    const localConfig = {
        port: 8081
    }
    config = extend(config, localConfig);
}

if (process.env.NODE_ENV == "production") {
    const pordConfig = {
        port: 8088
    }
    config = extend(config, pordConfig);
}

export default config;