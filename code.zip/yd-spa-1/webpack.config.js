const HtmlWebpackPlugin = require('html-webpack-plugin');
const merge = require('webpack-merge');
const MiniCssExtractPlugin = require("mini-css-extract-plugin");


const argv = require('yargs-parser')(process.argv.slice(2));
const _mode = argv.mode || 'development';
const _modeflag = _mode == 'production' ? true : false;
const _mergeConfig = require(`./config/webpack.${_mode}.js`);
let webpackConfig = {
    module: {
        rules: [
            {
                test: /\.css$/,
                use: [{
                    loader: MiniCssExtractPlugin.loader,
                    // options: {
                    //     // you can specify a publicPath here
                    //     // by default it use publicPath in webpackOptions.output
                    //     publicPath: '../'
                    // }
                }, {
                    loader: 'css-loader',
                    options: {
                        modules: true, // 否则login.js当中嵌入的css类不起作用
                        localIdentName: '[name]--[hash:base64:5]'
                    }
                }]
            }
        ]
    },
    devServer: {
        before(app){
            app.get("/api/test",(req,res)=>{
                res.json({
                    status: 200,
                    message: '接口通啦!!！！！'
                });
            });
        }
    },
    plugins: [
        new MiniCssExtractPlugin({
            filename: _modeflag ? "styles/[name].[hash:3].css" : "styles/[name].css",
            chunkFilename: _modeflag ? "styles/[id].[hash:3].css" : "styles/[id].css"
        }),
        new HtmlWebpackPlugin({
            filename: 'index.html',
            template: './src/index.html',
            minify: {// 是否压缩html（目前就没有压缩掉）
                removeComments: _modeflag,
                collapseWhitespace: _modeflag
            }
        })
    ]
}

module.exports = merge(_mergeConfig, webpackConfig);