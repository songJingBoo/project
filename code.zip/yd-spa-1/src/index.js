import { login } from "./components/login/login.js"
// 为了防止主包太大，异步加载banner模块（打包的时候也会打成单独的一个包）,魔法注释就是给这个包起个名字
import(/*webpackChunkName: "banner"*/ "./components/banner/banner.js").then(_=>{
    _.default.init();
});
console.log("应用启动成功！");
login();