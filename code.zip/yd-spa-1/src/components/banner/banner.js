const asyncbanner = {
    init(){
        console.log("banner");
    }
}

export default asyncbanner;