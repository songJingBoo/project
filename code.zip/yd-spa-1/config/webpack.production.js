module.exports = {
    output: {
        filename: 'scripts/[name].[hash:3].bundles.js',
        publicPath: '/', // 公司cdn
    }
}