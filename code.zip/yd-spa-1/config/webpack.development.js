module.exports = {
    output:{
        filename: true  ? 'scripts/[name].[hash:3].bundles.js' : 'scripts/[name].bundles.js',
    }
}